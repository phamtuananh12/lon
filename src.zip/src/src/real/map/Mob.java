package real.map;
//share by chibikun
public class Mob {

    public int tempId;

    public byte level;

    public int hp;

    public int maxHp;

    public short pointX;

    public short pointY;
    
    public byte status;

    public void update() {

    }
}
