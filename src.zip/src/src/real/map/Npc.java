package real.map;
//share by chibikun
public class Npc {

    public int status;
    
    public int cx;
    
    public int cy;
    
    public int tempId;
    
    public int avartar;
}
