package real.clan;
//share by chibikun
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import server.DBService;

public class Member {

    public int id;

    public byte role;

    public long powerPoint;

    public int donate;

    public int receiveDonate;

    public int clanPoint;

    public int currPoint;

    public int joinTime;

}
