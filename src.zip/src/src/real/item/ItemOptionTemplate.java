package real.item;
//share by chibikun
public class ItemOptionTemplate {

    public int id;

    public String name;

    public int type;

}
