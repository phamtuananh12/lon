package real.task;
//share by chibikun
public class Task {

    public int index;

    public int max;

    public short[] counts;

    public short taskId;

    public String[] names;

    public String[] details;

    public String[] subNames;

    public String[] contentInfo;

    public short count;
}
