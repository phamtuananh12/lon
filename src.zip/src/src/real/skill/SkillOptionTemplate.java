package real.skill;
//share by chibikun
public class SkillOptionTemplate {

    public int id;

    public String name;
}
