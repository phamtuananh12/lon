package real.skill;
//share by chibikun
public class Skill {
    
	public SkillTemplate template;

	public short skillId;

	public int point;

	public long powRequire;

	public int coolDown;

	public long lastTimeUseThisSkill;

	public int dx;

	public int dy;

	public int maxFight;

	public int manaUse;

	public SkillOption[] options;

	public boolean paintCanNotUseSkill;

	public short damage;

	public String moreInfo;

	public short price;
}
